<?php
    $mysqluser = ("www-data"); //www-data
    $mysqlpass = ("shmeegol_shmorf"); //shmeegol_shmorf
    $database = ("db1");
    $localhost = "localhost";
